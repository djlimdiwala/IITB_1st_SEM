This python code finds valid tags used in the error-free HTML code.
One regular expression is used to find all tags.
All valid tags are stored in tag.txt file.

This code contains one regular expression.
-----------------------------------------------------------------

It reads file index.html and finds valid tags and store them in tag.txt file.

Run $ python tag_finder.py


