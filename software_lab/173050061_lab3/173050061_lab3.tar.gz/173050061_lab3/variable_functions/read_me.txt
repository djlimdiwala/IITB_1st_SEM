In this variable and function code, It will give all variables and functions used in the error-free C program.
All variables are stored in the variable.txt file.
All functions are stored in the function.txt file.

This code contains two main regular expressions: one to find variables and other to find functions.
It also contains one other regular expression to remove values assigned to variables for example, y =0  -> y
 
----------------------------------------------------------------------------

It will find vaiables and functions from reverse.c file

Run $ python finder.py


