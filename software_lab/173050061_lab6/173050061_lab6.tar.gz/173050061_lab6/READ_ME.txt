commamd to execute:

$ python3  solution.py  input.csv 1234


Here, code reads csv file and finds work no. and makes one sheet per occurence.
It also checks for some errors like if there is no coloumn with work no as substring, if there is no row with work no given from command line argument.