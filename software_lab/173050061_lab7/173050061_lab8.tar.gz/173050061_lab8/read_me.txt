In this assignment, all imports and exports are measured according to value(INR) of the product as some produxts have unspecified units.

In some cases quatity is given zero but value is non zero even if the unit is specified. which I assumed that transaction(import/export) was performed in earlier years but payment was due. So, payment was done in the 2011-12 or 2012-13 without doing any goods transfer(0 quatity).

Here, one country is UNSPECiFIED. I assumed that all goods which were imported or exported illegally to country
are grouped with country UNSPECIFIED.

In code solution.py, there are 7 functions
q_1()  --  answer of question 1
q_2()  --  answer of question 2
q_3()  --  answer of question 3
q_4()  --  answer of question 4
q_5()  --  answer of question 5
q_6()  --  answer of question 6
q_7()  --  answer of question 7

Results are stored in 173050061_solution.xls file with defined format.